# First-Seaborn-Project
My first work with Seaborn, a comprehensive seaborn function Notebook

This Work is done to make an comprehensive list of Seaborn Plots 

Criticism is welcome !!
